/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
/*
Name : Hemalatha J
college: Vivekananda college of engineering for women
Used data: email id, location, report type
method:nested if
*/
#include <iostream>


using namespace std;
  

int main() {
    string email, location, reportType;
    cout<<"*****WEATHER APP*****\n";
    cout << "Enter your email address: ";
    cin>>email;
    cout << "Enter your location: ";
    cin>>location;
    cout << "Do you want the weather for a specific day or for the week? (Enter 'day' or 'week'): ";
    cin>>reportType;
    cout << "Here's the " << reportType << " report for " << location << ":\n";
    if (reportType == "day") {
        int date;
        cout<<"enter date:\n";
        cin>>date;
        cout<<"The climate is:\n";
        cout<<"date:"<<date<<"\n";
        cout << "weather: Sunny\n";
        cout<<"TEMPERATURE:\n";
        cout << "High: 75°F\n";
        cout << "Low: 55°F\n";
    } else if (reportType == "week") {
cout << "Date: May 7, 2023\n";
        cout << "Day : sunday\n";
        cout << "Weather: Sunny\n";cout << "Date: May 7, 2023\n";
        cout << "Day : sunday\n";
        cout << "Weather: Sunny\n";
cout << "Date: May 8, 2023\n";
        cout << "Day : monday\n";
        cout << "Weather:cloudy\n";
cout << "Date: May 9, 2023\n";
        cout << "Day :Tuesday\n";
        cout << "Weather: Sunny\n";
        cout << "Date: May 10, 2023\n";
        cout << "Day : Wednesday\n";
        cout << "Weather:dry\n";
        cout << "Date: May 11, 2023\n";
        cout << "Day : Thursday\n";
        cout << "Weather: Sunny\n";
cout << "Date: May 12, 2023\n";
        cout << "Day : Friday \n";
        cout << "Weather: Thunderstorms\n";
cout << "Date: May 13, 2023\n";
        cout << "Day : saturday\n";
        cout << "Weather: Cloudy\n";
    } else {
        cout << "Invalid report:\n";
    }
    return 0;
}








    
